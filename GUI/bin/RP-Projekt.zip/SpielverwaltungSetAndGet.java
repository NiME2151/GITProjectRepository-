
public class SpielverwaltungSetAndGet {

	
private String Titel
}
